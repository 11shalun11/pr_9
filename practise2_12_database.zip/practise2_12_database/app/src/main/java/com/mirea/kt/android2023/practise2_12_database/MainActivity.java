package com.mirea.kt.android2023.practise2_12_database;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private EditText modelEditText;
    private EditText serialNumberEditText;
    private EditText priceEditText;
    private PhoneDbHelper dbHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        modelEditText = findViewById(R.id.modelEditText);
        serialNumberEditText = findViewById(R.id.serialNumberEditText);
        priceEditText = findViewById(R.id.priceEditText);
        dbHelper = new PhoneDbHelper(this);

        Button nextActivityButton = findViewById(R.id.nextActivityButton);
        nextActivityButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, PhoneListActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });

        Button saveButton = findViewById(R.id.saveButton);
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SQLiteDatabase db = dbHelper.getWritableDatabase();
                ContentValues values = new ContentValues();
                // Проверяем корректность введенных значений
                String model = modelEditText.getText().toString().trim();
                if (model.isEmpty()) {
                    modelEditText.setError("Требуется название модели");
                    modelEditText.requestFocus();
                    return;
                }
                String serialNumber = serialNumberEditText.getText().toString().trim();
                if (serialNumber.isEmpty()) {
                    serialNumberEditText.setError("Требуется серийный номер");
                    serialNumberEditText.requestFocus();
                    return;
                }
                String priceStr = priceEditText.getText().toString().trim();
                if (priceStr.isEmpty()) {
                    priceEditText.setError("Требуется цена");
                    priceEditText.requestFocus();
                    return;
                }
                int price = Integer.parseInt(priceStr);
                if (price <= 0) {
                    priceEditText.setError("Цена должна быть больше 0");
                    priceEditText.requestFocus();
                    return;
                }
                // Добавляем корректные значения в БД
                values.put(PhoneContract.PhoneEntry.COLUMN_NAME_MODEL, model);
                values.put(PhoneContract.PhoneEntry.COLUMN_NAME_SERIAL_NUMBER, serialNumber);
                values.put(PhoneContract.PhoneEntry.COLUMN_NAME_PRICE, price);
                long newRowId = db.insert(PhoneContract.PhoneEntry.TABLE_NAME, null, values);
                // Очищаем поля ввода
                modelEditText.getText().clear();
                serialNumberEditText.getText().clear();
                priceEditText.getText().clear();
            }
        });
    }
}