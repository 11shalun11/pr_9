package com.mirea.kt.android2023.practise2_12_database;

import android.provider.BaseColumns;

public final class PhoneContract {

    private PhoneContract() {}

    public static class PhoneEntry implements BaseColumns {
        public static final String TABLE_NAME = "phones";
        public static final String COLUMN_NAME_MODEL = "model";
        public static final String COLUMN_NAME_SERIAL_NUMBER = "serial_number";
        public static final String COLUMN_NAME_PRICE = "price";
    }
}