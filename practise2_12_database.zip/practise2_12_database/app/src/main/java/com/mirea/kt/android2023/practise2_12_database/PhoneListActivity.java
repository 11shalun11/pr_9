package com.mirea.kt.android2023.practise2_12_database;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class PhoneListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_phone_list);

        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        List<Phone> phones = new ArrayList<>();

        PhoneDbHelper dbHelper = new PhoneDbHelper(this);
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String[] projection = {
                PhoneContract.PhoneEntry._ID,
                PhoneContract.PhoneEntry.COLUMN_NAME_MODEL,
                PhoneContract.PhoneEntry.COLUMN_NAME_SERIAL_NUMBER,
                PhoneContract.PhoneEntry.COLUMN_NAME_PRICE
        };
        String sortOrder =
                PhoneContract.PhoneEntry.COLUMN_NAME_MODEL + " DESC";
        Cursor cursor = db.query(
                PhoneContract.PhoneEntry.TABLE_NAME,   // The table to query
                projection,
                null,
                null,
                null,
                null,
                sortOrder
        );


        while (cursor.moveToNext()) {
            long itemId = cursor.getLong(
                    cursor.getColumnIndexOrThrow(PhoneContract.PhoneEntry._ID));
            String model = cursor.getString(
                    cursor.getColumnIndexOrThrow(PhoneContract.PhoneEntry.COLUMN_NAME_MODEL));
            String serialNumber = cursor.getString(
                    cursor.getColumnIndexOrThrow(PhoneContract.PhoneEntry.COLUMN_NAME_SERIAL_NUMBER));
            int price = cursor.getInt(
                    cursor.getColumnIndexOrThrow(PhoneContract.PhoneEntry.COLUMN_NAME_PRICE));
            phones.add(new Phone(itemId, model, serialNumber, price));
        }
        cursor.close();

        PhoneAdapter adapter = new PhoneAdapter(phones);
        recyclerView.setAdapter(adapter);

        Button backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    public void onButtonClick(View view) {
        if(view.getId() == R.id.backButton) {
            finish();
        }
    }
}