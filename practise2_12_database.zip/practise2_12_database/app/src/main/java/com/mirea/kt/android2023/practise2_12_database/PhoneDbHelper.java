package com.mirea.kt.android2023.practise2_12_database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class PhoneDbHelper extends SQLiteOpenHelper {

    public static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "phones.db";

    public PhoneDbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String SQL_CREATE_ENTRIES =
                "CREATE TABLE " + PhoneContract.PhoneEntry.TABLE_NAME + " (" +
                        PhoneContract.PhoneEntry._ID + " INTEGER PRIMARY KEY," +
                        PhoneContract.PhoneEntry.COLUMN_NAME_MODEL + " TEXT," +
                        PhoneContract.PhoneEntry.COLUMN_NAME_SERIAL_NUMBER + " TEXT," +
                        PhoneContract.PhoneEntry.COLUMN_NAME_PRICE + " INTEGER)";

        db.execSQL(SQL_CREATE_ENTRIES);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // TODO: implement database upgrade
    }
}