package com.mirea.kt.android2023.practise2_12_database;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
import java.util.Locale;

public class PhoneAdapter extends RecyclerView.Adapter<PhoneAdapter.ViewHolder> {

    private List<Phone> phones;

    public PhoneAdapter(List<Phone> phones) {
        this.phones = phones;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private TextView modelTextView;
        private TextView serialNumberTextView;
        private TextView priceTextView;

        public ViewHolder(View view) {
            super(view);
            modelTextView = view.findViewById(R.id.modelTextView);
            serialNumberTextView = view.findViewById(R.id.serialNumberTextView);
            priceTextView = view.findViewById(R.id.priceTextView);
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.phone_item_layout, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Phone phone = phones.get(position);
        holder.modelTextView.setText(phone.getModel());
        holder.serialNumberTextView.setText(phone.getSerialNumber());
        holder.priceTextView.setText(String.format(Locale.getDefault(), "%d руб.", phone.getPrice()));
    }

    @Override
    public int getItemCount() {
        return phones.size();
    }
}